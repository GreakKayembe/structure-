<style>
    footer{
        background-color: #B2D235;
    }

    .des{
        border-radius:18px;
    }

     #nav-link i:hover{
            color: yellow !important; /* Jaune pâle */
        }
</style>

<footer class="bg- #B2D235 text-white text-center py-4">
        <p>L'INFO CONTINUE SUR :</p>
        <a href="hpps//www.facebook.com/profile.php?id=100063820673871&mibextid=ZbWKwL"  id="nav-link"  target="_blank" class="text-white mx-2" style="text-decoration:none;"><img src="assets/tabler-icons/f.ico" alt="" srcset="" width="14px" height="14" border-radius="18px"></a>
        <a href="https//x.com/CongoAvant?t=D4lx30oEG48DKI8ZDaCr-A&s=09"  target="_blank"  id="nav-link" class="text-white mx-2" style="text-decoration:none;"><img src="assets/tabler-icons/X.ico" alt="" srcset="" width="14px" height="14" border-radius="18px"></i></a>
        <a href="mailto:info@mca-rdc.org"  target="_blank" class="text-white mx-2"  id="nav-link" style="text-decoration:none;"><img src="assets/tabler-icons/email.ico" alt="" srcset="" width="14px" height="14" border-radius="18px"></a>
        <a href="https://wa.me/243976471254" target="_blank" class="text-white mx-2"  id="nav-link" style="text-decoration:none;" ><img src="assets/tabler-icons/wt.ico" alt="" srcset=""  width="14px" height="14" border-radius="18px"></a>
        <a href="https://youtube.com/@echo7tv24?si=ZdH02uWvkyjjb7" target="_blank" class="text-white mx-2"  id="nav-link" style="text-decoration:none;" ><img src="assets/tabler-icons/tube" alt="" srcset="" width="14px" height="14" border-radius="18px" ></a>

        <p>&copy; <?php echo date("Y"); ?> Mouvement C<img  class="des" src="assets/images/logos.jpg" width="14px" height="14" border-radius="18px" alt="">ngo en Avant</p>
        <p><i class="ti ti-map-pin"></i>Kinshasa-Bandalungwa, Avenue Ntimasi n°47, Q/Bisengo C/Bandalungwa, </p>
    </footer>